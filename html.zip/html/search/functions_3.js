var searchData=
[
  ['distribucio_5ftret',['distribucio_tret',['../class_cjt__trets.html#a494637690de84a2115e5b7d45fcc8e51',1,'Cjt_trets']]],
  ['donar_5fmida',['donar_mida',['../class_individu.html#ad2094ead7cc6d4fa18c74e264f220c5b',1,'Individu']]]
];

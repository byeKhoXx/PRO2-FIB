var searchData=
[
  ['escriure_5fpar_5fcromo',['escriure_par_cromo',['../class_individu.html#a7a508b4f1cce842417cb71bae99f0850',1,'Individu']]],
  ['exportar_5find_5fpar_5fcromo',['exportar_ind_par_cromo',['../class_cjt__individus.html#aebe68a22c8154b6c3609e94d96f4d7b6',1,'Cjt_individus']]],
  ['exportar_5fpar_5fcromo',['exportar_par_cromo',['../class_individu.html#a5903d20d6eb1a4486ad71d367483581c',1,'Individu']]]
];

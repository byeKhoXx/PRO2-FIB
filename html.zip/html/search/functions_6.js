var searchData=
[
  ['llegir',['llegir',['../class_cjt__individus.html#a478b829d6a11c5259a36a8bd53662e7d',1,'Cjt_individus']]],
  ['llegir_5farbre',['llegir_arbre',['../class_cjt__trets.html#a3eac4d943cad163f4cac5d0ecc7be55c',1,'Cjt_trets']]],
  ['llegir_5fpar_5fcromo',['llegir_par_cromo',['../class_individu.html#a609aeb2bf726299e7944139a705ecff6',1,'Individu']]]
];

var searchData=
[
  ['afegir_5find_5fsecuencia_5ftret',['afegir_ind_secuencia_tret',['../class_tret.html#aa37ad2e1cbffa0b7c39562c189943c45',1,'Tret']]],
  ['afegir_5fnom_5find_5ftret',['afegir_nom_ind_tret',['../class_tret.html#ab0d563272f8e42f9e18210cd0b78ab9e',1,'Tret']]],
  ['afegir_5ftret',['afegir_tret',['../class_cjt__trets.html#a531fdc9cc8444910abdf7ae59d8de5ad',1,'Cjt_trets']]],
  ['arbre',['arbre',['../class_cjt__trets.html#ad8b566a8f167bea84219938810b4630b',1,'Cjt_trets']]],
  ['arbre_5fdistribuit',['arbre_distribuit',['../class_cjt__trets.html#a5257638659be165e4fb652b63feef52f',1,'Cjt_trets']]],
  ['aplicació_20per_20a_20un_20laboratori_20de_20biologia_2e',['Aplicació per a un laboratori de biologia.',['../index.html',1,'']]]
];

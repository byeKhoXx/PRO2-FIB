var indexSectionsWithContent =
{
  0: "abcdeilmnprstv~",
  1: "cit",
  2: "cipt",
  3: "abcdeilmnrt~",
  4: "amnpsv",
  5: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Pàgines"
};


var searchData=
[
  ['par_5fcromo',['par_cromo',['../class_individu.html#a4fb3fd4e797e1634ed90080de61f4567',1,'Individu']]]
];

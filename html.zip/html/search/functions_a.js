var searchData=
[
  ['tret',['Tret',['../class_tret.html#a3c892a10a6d209029a303b46b1deff17',1,'Tret']]],
  ['trets_5findividu',['trets_individu',['../class_cjt__trets.html#a03b83caa9072f6c0ba0af5460f4ff2e4',1,'Cjt_trets']]],
  ['treure_5find_5fsecuencia_5ftret',['treure_ind_secuencia_tret',['../class_tret.html#a096e52b3a9d42334536ae853d44ea141',1,'Tret']]],
  ['treure_5ftret',['treure_tret',['../class_cjt__trets.html#ae707a901ff76353e89fd1a4273827a85',1,'Cjt_trets']]]
];

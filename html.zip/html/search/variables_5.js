var searchData=
[
  ['vind',['vind',['../class_cjt__individus.html#a3c8f7d6c8b867701ed4c3fe2f504dfa8',1,'Cjt_individus']]]
];

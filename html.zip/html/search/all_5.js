var searchData=
[
  ['imprimir_5farbre',['imprimir_arbre',['../class_cjt__trets.html#a020b3f64381b38922d92035071bdc7c3',1,'Cjt_trets']]],
  ['imprimir_5fnom_5findividus_5ftret',['imprimir_nom_individus_tret',['../class_tret.html#a4f79b349d729d2b6f243cfe0d0a079ba',1,'Tret']]],
  ['imprimir_5fsecuencia_5ftret',['imprimir_secuencia_tret',['../class_tret.html#add6e974760ae15b4293c987519ffac1e',1,'Tret']]],
  ['individu',['Individu',['../class_individu.html',1,'Individu'],['../class_individu.html#ac35091404cfbf11946694806aefa9e7e',1,'Individu::Individu()']]],
  ['individu_2ecc',['Individu.cc',['../_individu_8cc.html',1,'']]],
  ['individu_2ehh',['Individu.hh',['../_individu_8hh.html',1,'']]],
  ['insertar_5fsecuencia_5ftret',['insertar_secuencia_tret',['../class_tret.html#a26d262e91384fde0443042ffafbc9e06',1,'Tret']]]
];

var searchData=
[
  ['buscar_5findividu',['buscar_individu',['../class_tret.html#a7b06ffc8d478873c027ad7dc121f55ce',1,'Tret']]]
];
